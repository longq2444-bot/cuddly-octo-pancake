Terra Invicta Real-Time Trainer
ONE-CLICK INSTALL
=================
1. Have Terra Invicta installed and launched once via Steam.
2. Double-click TIAutoInstall.exe.
   It auto-locates the game, checks compatibility by inspecting the game code,
   installs BepInEx if missing, and deploys the plugin + trainer.
3. Launch the game, enter a campaign, open TIRealTimeTrainer.exe - done.

FEATURES
- Money / Influence / Operations / Boost / Research / Mission Control / CP Cap
- 7 space resources (Metals, Noble Metals, Volatiles, Fissiles, Water, Antimatter, Exotics)
- Status locks with auto-replenish (Money / Influence / Operations / Research)
- Selected councilor: max stats / loyalty 25 / +5000 XP / age -20
- All your councilors: lock loyalty / learn all missions (AI unaffected)
- Selected nation: GDP / Education / Democracy / Cohesion / Unrest / Mil Tech / Nukes
- God mode: full vision / full intel / complete projects / reset alien hate

FAQ
- 'Not connected'? You must be inside a campaign; whitelist in antivirus.
- 'WebView2Loader.dll' error? Install Microsoft Edge WebView2 Runtime (Evergreen).
- Trainer won't start? Install .NET 9 Desktop Runtime (x64) from microsoft.com.
- Uninstall: delete winhttp.dll, doorstop_config.ini, BepInEx folder, and BepInEx\plugins\TICheat.

FEEDBACK / BUGS
- Found a bug or have a suggestion? Email: longq2444@gmail.com
- Please include your game version and a short description of the issue.

Single-player only.
